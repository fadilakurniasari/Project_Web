<!DOCTYPE html>
<html>
<head>
	<title>Project 2 | Fadila Kurnia Sari</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="jquery.js"></script>
</head>

<body>
<div class="content">
	<header>
		<h1 class="judul">PROJECT DUA</h1>
		<h3 class="deskripsi">Membuat CRUD Menggunakan PHP</h3>
	</header>
<html>

<?php
include_once("config.php");
 
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$nama=$_POST['nama'];
	$jk=$_POST['jk'];
	$tgl_lahir=$_POST['tgl_lahir'];
	$jurusan=$_POST['jurusan'];
	$alamat=$_POST['alamat'];
	$no_hp=$_POST['no_hp'];
		
	
	$result = mysqli_query($mysqli, "UPDATE anggota SET nama='$nama',jk='$jk
		',tgl_lahir='$tgl_lahir',jurusan='$jurusan',alamat='$alamat',no_hp='$no_hp' WHERE id=$id");
	
	
	header("Location: index.php");
}
?>

<?php
$id = $_GET['id'];
 
$result = mysqli_query($mysqli, "SELECT * FROM anggota WHERE id=$id");
 
while($user_data = mysqli_fetch_array($result))
{
	$nama = $user_data['nama'];
	$jk = $user_data['jk'];
	$tgl_lahir = $user_data['tgl_lahir'];
	$jurusan = $user_data['jurusan'];
	$alamat = $user_data['alamat'];
	$no_hp = $user_data['no_hp'];
}
?>
<html>
<head>	
	<title>Edit Data Anggota</title>
</head>
 
<body align="center">
	<a href="index.php">Home</a>
	<br/><br/>
	
	<form name="update_user" method="post" action="edit.php">
		<table align="center" border="0">
			<tr> 
				<td>Nama</td>
				<td></td>
				<td><input type="text" name="nama" value=<?php echo $nama;?>></td>
			</tr>
			<tr> 
				<td>Jenis Kelamin</td>
				<td></td>
				<td><input type="text" name="jk" value=<?php echo $jk;?>></td>
			</tr>
			<tr> 
				<td>Tanggal Lahir</td>
				<td></td>
				<td><input type="text" name="tgl_lahir" value=<?php echo $tgl_lahir;?>></td>
			</tr>
			<tr> 
				<td>Jurusan</td>
				<td></td>
				<td><input type="text" name="jurusan" value=<?php echo $jurusan;?>></td>
			</tr>
			<tr> 
				<td>Alamat</td>
				<td></td>
				<td><input type="text" name="alamat" value=<?php echo $alamat;?>></td>
			</tr>
			<tr> 
				<td>No Telepon</td>
				<td></td>
				<td><input type="number" name="no_hp" value=<?php echo $no_hp;?>></td>
			</tr>
			<tr></tr>
			<tr></tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>