<!DOCTYPE html>
<html>
<head>
	<title>Project 2 | Fadila Kurnia Sari</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="jquery.js"></script>
</head>

<body>
<div class="content">
	<header>
		<h1 class="judul">PROJECT DUA</h1>
		<h3 class="deskripsi">Membuat CRUD Menggunakan PHP</h3>
	</header>
<html>
<head>
	<title>Tambah Anggota</title>
</head>
 
<body align="center">
	<a href="index.php">Kembali Ke Tambah Data</a>
	<br/><br/>
 
	<form action="add.php" method="post" name="form1">
		<table align="center" width="25%" border="0">
			<tr> 
				<td>Nama</td>
				<td></td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr> 
				<td>Jenis Kelamin</td>
				<td></td>
				<td><input type="text" name="jk"></td>
			</tr>
			<tr> 
				<td>Tanggal Lahir</td>
				<td></td>
				<td><input type="text" name="tgl_lahir"></td>
			</tr>
			<tr> 
				<td>Jurusan</td>
				<td></td>
				<td><input type="text" name="jurusan"></td>
			</tr>
			<tr> 
				<td>Alamat</td>
				<td></td>
				<td><input type="text" name="alamat"></td>
			</tr>
			<tr> 
				<td>No Telepon</td>
				<td></td>
				<td><input type="number" name="no_hp"></td>
			</tr>
			<tr></tr>
			<tr> 
				<td></td>
				<td></td>
				<td><input type="submit" name="Submit" value="Tambah"></td>
			</tr>
		</table>
	</form>
	
	<?php
 
	if(isset($_POST['Submit'])) {
		$nama = $_POST['nama'];
		$jk = $_POST['jk'];
		$tgl_lahir = $_POST['tgl_lahir'];
		$jurusan = $_POST['jurusan'];
		$alamat = $_POST['alamat'];
		$no_hp = $_POST['no_hp'];
		
		include_once("config.php");
				
		$result = mysqli_query($mysqli, "INSERT INTO anggota(nama,jk,tgl_lahir,jurusan,alamat,no_hp) VALUES('$nama','$jk','$tgl_lahir','$jurusan','$alamat','no_hp')");
		
		echo "Data Anggota Berhasil Ditambah. <a href='index.php'>Lihat Data Anggota</a>";
	}
	?>

</body>
</html>